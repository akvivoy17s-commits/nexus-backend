'use strict';
const Snd=(()=>{
  let ac,m=false,mus=-1,boss=false,step=0;
  const init=()=>{if(!ac){try{ac=new(window.AudioContext||window.webkitAudioContext)()}catch(e){}}if(ac&&ac.state==='suspended')ac.resume()};
  const cfg={music:true,sfx:true};const tone=(f,d,type='square',v=.06,sl=0,mu=0)=>{if(!ac||m||!(mu?cfg.music:cfg.sfx))return;const o=ac.createOscillator(),g=ac.createGain(),t=ac.currentTime;
    o.type=type;o.frequency.setValueAtTime(f,t);if(sl)o.frequency.exponentialRampToValueAtTime(Math.max(30,f+sl),t+d);
    g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+d);o.connect(g);g.connect(ac.destination);o.start(t);o.stop(t+d)};
  const fx={jump:()=>tone(300,.15,'square',.05,350),coin:()=>{tone(880,.07);setTimeout(()=>tone(1320,.1),60)},punch:()=>tone(160,.12,'sawtooth',.08,-80),
    kunai:()=>tone(900,.08,'triangle',.06,-500),hurt:()=>tone(240,.3,'sawtooth',.09,-150),boom:()=>tone(110,.6,'sawtooth',.12,-70),
    power:()=>[523,659,784,1046].forEach((f,i)=>setTimeout(()=>tone(f,.12),i*70)),win:()=>[523,659,784,1046,1318].forEach((f,i)=>setTimeout(()=>tone(f,.2,'triangle',.08),i*110))};
  const sc=[[262,294,330,392,440],[220,262,294,330,392],[196,233,262,294,349]],pat=[0,2,4,2,3,1,2,0],bp=[0,0,4,0,3,0,4,3];
  setInterval(()=>{if(!ac||m||mus<0)return;const s=sc[mus],p=boss?bp:pat,n=s[p[step%8]]*(boss?1:1);
    tone(n,.2,boss?'sawtooth':'triangle',boss?.035:.04,0,1);if(step%4===0)tone(s[0]/2,.45,'sine',.06,0,1);step++},200);
  return{init,fx,cfg,mute:()=>m=!m,music:n=>{mus=n<0?-1:n%3;boss=false},boss:b=>boss=b};
})();
