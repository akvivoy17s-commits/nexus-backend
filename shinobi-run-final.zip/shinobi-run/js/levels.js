'use strict';
const THEMES=[
 {name:'Leaf Forest',sky:['#5fb7f0','#d8f0ff'],far:'#8fb8d0',near:'#4f9a56',g:'#7a4f2a',gt:'#4caf50',p:'#b07a3a'},
 {name:'Bridge of Waves',sky:['#f08a5f','#ffe9b8'],far:'#a0708a',near:'#3a6a8a',g:'#6a6a7a',gt:'#9ab4c8',p:'#8a7a5a'},
 {name:'Valley of the End',sky:['#1e2352','#8a6a9a'],far:'#3a3a6a',near:'#2a2a4a',g:'#4a4a5a',gt:'#8a8aaa',p:'#6a5a7a'},
 {name:'Sound Hideout',sky:['#2a1a3a','#5a2a4a'],far:'#4a2a5a',near:'#2a1a3a',g:'#3a2a4a',gt:'#8a4aaa',p:'#5a3a6a'},
 {name:'Hokage Cliffs',sky:['#3a0a0a','#e0602a'],far:'#6a2a1a',near:'#3a1a1a',g:'#5a3a2a',gt:'#c06a2a',p:'#8a4a2a'}];
const BOSSES=[{name:'Mist Swordsman',hp:10,col:'#4a5a7a'},{name:'Rogue Puppeteer',hp:14,col:'#7a4a3a'},{name:'Rival of the Valley',hp:18,col:'#3a2a5a'},{name:'Snake Sannin',hp:22,col:'#4a6a3a'},{name:'The Masked Leader',hp:30,col:'#3a1a1a',f:true}];
const STORY=[
 {intro:['Konoha is in danger, Naruto!','Rogue ninja stole the Hidden Leaf scrolls.','Chase them through the Leaf Forest. Believe it!'],
  clear:['The Mist Swordsman falls!','His map points to the Land of Waves...']},
 {intro:['World 2: Bridge of Waves.','Sound ninja guard the old bridge.','Your chakra surges: DOUBLE JUMP unlocked!'],
  clear:['The Puppeteer is beaten.','But one trail remains: the Valley of the End.']},
 {intro:['World 3: Valley of the End.','An old rival waits at the waterfall.','Show him the strength of your will!'],
  clear:['The rival is down... but the scrolls are not here.','The journey is far from over.']},
 {intro:['World 4: The Sound Hideout.','The Snake Sannin hides the scrolls here.','Rasengan ready? Go!'],
  clear:['The Sannin retreats!','A masked figure waits on the Hokage Cliffs...']},
 {intro:['Final World: Hokage Cliffs.','The Masked Leader wants every scroll.','This is it, Naruto. Protect your village!'],
  clear:['The Masked Leader is defeated!','The scrolls return to Konoha. You are a hero!']}];
const mb=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};

class Level{
  constructor(n){
    const r=mb(n*97+5);
    Object.assign(this,{n,th:THEMES[n],w:150+n*20,h:17,bossDef:BOSSES[n],coins:[],hearts:[],pups:[],enemies:[],checks:[]});
    const A=this.w-26,t=this.t=Array.from({length:17},()=>Array(this.w).fill(' '));
    this.arena=A;this.arenaX=A*TS;this.goalX=(this.w-5)*TS;
    for(let x=0;x<this.w;x++)t[15][x]=t[16][x]='#';
    const plat=(x,y,l)=>{for(let i=0;i<l;i++){t[y][x+i]='=';this.coins.push([(x+i)*TS+8,(y-1)*TS+8])}};
    const P=[['ninja','ninja','bird'],['ninja','shooter','bird','brute'],['ninja','shooter','brute','bird','shooter'],['ninja','shooter','brute','bird','brute','shooter'],['brute','shooter','brute','bird','ninja','shooter']][n];
    const en=x=>{const ty=P[r()*P.length|0];this.enemies.push([ty,x*TS,ty==='bird'?(8+(r()*3|0))*TS:15*TS-ET[ty].h])};
    let x=9,nc=45;
    while(x<A-8){
      const k=r();
      if(k<.22){const g=2+(r()*2|0);for(let i=0;i<g;i++)t[15][x+i]=t[16][x+i]=' ';plat(x-1,12,g+2);x+=g+6}
      else if(k<.4){t[14][x]=t[13][x]='#';x+=7}
      else if(k<.58){t[14][x]=t[14][x+1]='^';x+=7}
      else if(k<.84){plat(x,12,3);plat(x+4,9,3);if(r()<.5)this.hearts.push([(x+5)*TS+8,7*TS+8]);
        if(r()<.6){plat(x+8,6,3);this.pups.push(['rch'[r()*3|0],(x+9)*TS+6,4*TS+6])}x+=13}
      else{for(let i=0;i<3;i++)this.coins.push([(x+i)*TS+8,14*TS+8]);x+=4}
      if(r()<.55+.07*n)en(x-2);
      if(x>nc){this.checks.push({x:x*TS,y:15*TS-64,on:false});nc+=45}
    }
  }
  ch(x,y){return x<0||x>=this.w?'#':y<0||y>=this.h?' ':this.t[y][x]}
  solid(x,y){const c=this.ch(x,y);return c==='#'||c==='='}
  hit(e){
    for(let y=Math.floor(e.y/TS);y<=Math.floor((e.y+e.h-.01)/TS);y++)
      for(let x=Math.floor(e.x/TS);x<=Math.floor((e.x+e.w-.01)/TS);x++)if(this.solid(x,y))return{x,y};
    return null;
  }
}
