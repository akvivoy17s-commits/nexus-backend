'use strict';
const R=(c,col,x,y,w,h)=>{c.fillStyle=col;c.fillRect(x,y,w,h)};
let _t=0;const G_time=()=>_t,tick=()=>_t++;
const ET={ninja:{w:24,h:34,hp:2,sp:1.1,pts:100},shooter:{w:24,h:34,hp:2,sp:0,pts:150},brute:{w:34,h:48,hp:5,sp:.7,pts:300},bird:{w:28,h:20,hp:1,sp:0,pts:80}};
const COL={ninja:'#5b4a8a',shooter:'#3a6a4a',brute:'#7a3a3a'};

class Player{
  constructor(x,y){Object.assign(this,{x,y,w:22,h:38,vx:0,vy:0,face:1,hp:3,max:3,inv:0,coy:0,buf:0,atk:0,cd:0,kcd:0,anim:0,ground:false,jumps:0,pw:{r:0,c:0,h:0}})}
  update(G){
    const d=(down('ArrowRight','KeyD')?1:0)-(down('ArrowLeft','KeyA')?1:0),mx=(down('ShiftLeft','ShiftRight')?6:4.2)*(this.pw.h>0?1.3:1),J=['Space','ArrowUp','KeyW'];
    if(d){this.vx+=d*(this.ground?.7:.5);this.face=d}else this.vx*=this.ground?.78:.96;
    this.vx=Math.max(-mx,Math.min(mx,this.vx));
    if(this.ground)this.jumps=0;
    this.coy=this.ground?6:this.coy-1;
    this.buf=hit(...J)?7:this.buf-1;
    if(this.buf>0&&this.coy>0){this.vy=-12.5;this.buf=this.coy=0;this.ground=false;this.jumps=1;G.puff(this.x+11,this.y+38,5,'#ddd');Snd.fx.jump()}
    else if(this.buf>0&&G.dj&&!this.ground&&this.jumps<2){this.vy=-11;this.jumps=2;this.buf=0;G.puff(this.x+11,this.y+38,8,'#9df');Snd.fx.jump()}
    if(this.vy<-4&&!down(...J))this.vy=-4;
    this.vy=Math.min(this.vy+.6,15);
    if(hit('KeyJ')&&this.cd<=0){this.atk=12;this.cd=20;Snd.fx.punch()}
    if(hit('KeyK')&&this.kcd<=0&&G.shots.length<(this.pw.c>0?9:3)){for(const v of this.pw.c>0?[-1.5,0,1.5]:[0])G.shots.push(new Shot(this.x+11,this.y+16,this.face,v));this.kcd=22;Snd.fx.kunai()}
    this.cd--;this.kcd--;this.atk--;this.inv--;for(const k in this.pw)if(this.pw[k]>0)this.pw[k]--;
    const wg=this.ground;moveBody(this,G.level);
    if(this.ground&&!wg)G.puff(this.x+11,this.y+38,5,'#ccc');if(this.ground&&Math.abs(this.vx)>3&&G.time%6===0)G.puff(this.x+11-this.face*8,this.y+38,1,'#ccc');
    this.anim+=Math.abs(this.vx)*.15;
    if(this.atk>0){const b=this.fist();for(const e of G.enemies)if(!e.dead&&overlap(b,e))e.hurt(G,this.face,this.pw.r>0?3:1);
      if(G.boss.active&&!G.boss.dead&&overlap(b,G.boss))G.boss.hurt(G,this.face,this.pw.r>0?3:1)}
  }
  fist(){const l=this.pw.r>0?46:30;return{x:this.face>0?this.x+this.w:this.x-l,y:this.y+6,w:l,h:26}}
  hurt(G,dir){if(this.inv>0)return;this.hp--;this.inv=90;this.vy=-7;this.vx=dir*4;G.shake=8;G.puff(this.x+11,this.y+19,8,'#f33');Snd.fx.hurt();if(this.hp<=0)G.die()}
  draw(c){
    if(this.inv>0&&this.inv%8<4)return;
    const q=this.pw,t=G_time();
    if(q.r>0||q.c>0||q.h>0){c.globalAlpha=.25+.1*Math.sin(t*.3);c.fillStyle=q.r>0?'#4cf':q.c>0?'#fa3':'#4f6';c.beginPath();c.arc(this.x+11,this.y+20,28,0,7);c.fill();c.globalAlpha=1}
    if(q.h>0&&Math.abs(this.vx)>3){c.globalAlpha=.3;R(c,'#ff8a00',this.x-this.face*12,this.y+10,22,28);c.globalAlpha=1}
    c.save();c.translate(this.x+11,this.y);c.scale(this.face,1);
    const s=this.ground&&Math.abs(this.vx)>.5?Math.sin(this.anim)*6:(this.ground?0:5);
    R(c,'#e86a00',-9+s,26,8,12);R(c,'#e86a00',1-s,26,8,12);R(c,'#223',-9+s,35,8,3);R(c,'#223',1-s,35,8,3);
    R(c,'#ff8a00',-11,13,22,15);R(c,'#223',-11,13,22,4);R(c,'#223',-11,26,22,3);
    R(c,'#ff8a00',this.atk>0?4:-3-s*.5,15,8,6);if(this.atk>0)R(c,'#f5c9a0',10,15,10,6);
    c.fillStyle='#f5c9a0';c.beginPath();c.arc(0,8,9,0,7);c.fill();
    c.fillStyle='#ffd400';for(let i=-3;i<=3;i++){c.beginPath();c.moveTo(i*3-3,0);c.lineTo(i*3,-9-(i%2?3:0));c.lineTo(i*3+3,0);c.fill()}
    R(c,'#ffd400',-9,-1,18,4);R(c,'#2a4fc0',-9,3,18,4);R(c,'#ccd',-3,3,7,4);
    R(c,'#c9803f',5,10,3,1);R(c,'#c9803f',5,12,3,1);R(c,'#222',3,8,2,2);
    c.restore();
    if(this.atk>0&&q.r>0){const b=this.fist(),X=b.x+b.w/2,Y=b.y+13;c.fillStyle='#6cf';c.beginPath();c.arc(X,Y,15,0,7);c.fill();c.fillStyle='#fff';c.beginPath();c.arc(X,Y,7+Math.sin(t)*2,0,7);c.fill()}
  }
}

class Enemy{
  constructor(type,x,y){Object.assign(this,ET[type],{type,x,y,ox:x,oy:y,dir:-1,vx:0,vy:0,dead:false,flash:0,t:Math.random()*100|0,stomp:2})}
  update(G){if(this.dead){this.t++;return}this.flash--;this.ai(G);this.contact(G)}
  ai(G){
    const L=G.level,p=G.p;this.t++;
    if(this.type==='bird'){this.x=this.ox+Math.sin(this.t*.03)*90;this.y=this.oy+Math.sin(this.t*.07)*22;this.dir=Math.cos(this.t*.03)>0?1:-1;return}
    this.vy=Math.min(this.vy+.6,15);
    if(this.type==='shooter')this.dir=p.x<this.x?-1:1;
    else if(this.ground&&!L.solid(Math.floor((this.x+(this.dir>0?this.w+4:-4))/TS),Math.floor((this.y+this.h+4)/TS)))this.dir*=-1;
    this.vx=this.dir*this.sp;moveBody(this,L);
    if(this.hitX)this.dir*=-1;
    if(this.type==='shooter'&&Math.abs(p.x-this.x)<460&&this.t%110===0){G.es.push({x:this.x+12,y:this.y+14,vx:this.dir*5,vy:0,w:12,h:6});Snd.fx.kunai()}
  }
  contact(G){
    const p=G.p;
    if(overlap(this,p)){
      if(p.vy>1&&p.y+p.h<this.y+18){this.hurt(G,p.face,this.stomp);p.vy=-9}
      else p.hurt(G,p.x<this.x?-1:1);
    }
  }
  hurt(G,dir,dmg){
    if(this.flash>0)return;this.hp-=dmg;this.flash=14;if(this.type!=='bird'){this.x+=dir*4;if(G.level.hit(this))this.x-=dir*4}G.puff(this.x+this.w/2,this.y+this.h/2,6,'#fff');Snd.fx.punch();
    if(this.hp<=0){this.dead=true;G.score+=this.pts;G.puff(this.x+this.w/2,this.y+this.h/2,14,'#9af');G.txt.push({x:this.x+this.w/2,y:this.y,s:'+'+this.pts,life:40})}
  }
  draw(c){
    if(this.dead)return;
    const f=this.flash>0;
    if(this.type==='bird'){c.save();c.translate(this.x+14,this.y+10);c.scale(this.dir,1);const w=Math.sin(G_time()*.3)*8;
      R(c,f?'#fff':'#333',-12,-5,24,12);R(c,'#555',-8,-5+w*.3,16,3);R(c,'#555',-10,-12+w,8,8);R(c,'#fc0',12,-1,6,3);R(c,'#f33',6,-3,3,3);c.restore();return}
    c.save();c.translate(this.x+this.w/2,this.y);c.scale(this.dir,1);
    const w=this.w,h=this.h,s=this.sp?Math.sin(G_time()*.2)*5:0,col=f?'#fff':(this.boss?this.col:COL[this.type]);
    R(c,'#334',-w/3+s,h-10,w/3,10);R(c,'#334',2-s,h-10,w/3,10);
    R(c,col,-w/2,h*.32,w,h*.42);R(c,'#f5c9a0',-w/3,0,w*.66,h*.34);R(c,this.boss?'#ddd':'#556',-w*.4,-1,w*.8,h*.14);R(c,'#aab',-3,0,6,4);R(c,'#222',w*.12,h*.18,3,2);
    if(this.type==='shooter')R(c,'#aaa',w/2-2,h*.5,10,3);
    if(this.type==='brute'){R(c,'#999',-w/2-4,h*.3,6,18)}
    if(this.boss){R(c,'#bbc',w/2,-24,7,76);R(c,'#654',w/2-2,50,11,5);if(this.st==='tele'){c.scale(this.dir,1);text('!',0,-14,40,'#f33')}}
    c.restore();
  }
}

class Boss extends Enemy{
  constructor(def,x,y,m=1){super('ninja',x,y);const hp=Math.round(def.hp*m);Object.assign(this,{w:46,h:66,hp,max:hp,fin:!!def.f,name:def.name,col:def.col,boss:true,active:false,st:'walk',stt:0,next:'charge',stomp:1,pts:1000})}
  update(G){if(this.active)super.update(G)}
  go(s){this.st=s;this.stt=0}
  ai(G){
    const p=G.p,to=p.x<this.x?-1:1,ph2=this.hp<this.max/2;this.stt++;this.vy=Math.min(this.vy+.6,15);
    const rg=1-this.hp/this.max;
    if(this.st==='walk'){this.dir=to;this.vx=to*(1.1+rg*.9);if(this.stt>120-rg*50){const o=ph2||this.fin?['charge','leap','volley']:['charge','leap'];this.next=o[Math.random()*o.length|0];this.go('tele')}}
    else if(this.st==='tele'){this.vx=0;if(this.stt>28){this.go(this.next);if(this.next==='leap'){this.vy=-14;this.vx=to*5}else this.dir=to}}
    else if(this.st==='charge'){this.vx=this.dir*(7+rg*2);if(this.stt>35||this.hitX)this.go('walk')}
    else if(this.st==='leap'){if(this.ground&&this.stt>5)this.go('walk')}
    else if(this.st==='volley'){this.vx=0;if(this.stt%14===0){for(const v of this.fin?[-2,-1,0,1,2]:[-1.2,0,1.2])G.es.push({x:this.x+23,y:this.y+24,vx:this.dir*5,vy:v,w:12,h:6});Snd.fx.kunai()}if(this.stt>50)this.go('walk')}
    moveBody(this,G.level);
  }
  hurt(G,dir,dmg){
    if(this.flash>0||this.dead)return;this.hp-=dmg;this.flash=22;G.shake=6;G.puff(this.x+23,this.y+33,10,'#fff');Snd.fx.punch();
    if(this.hp<=0){this.dead=true;G.score+=this.pts;G.shake=25;G.flash=30;G.puff(this.x+23,this.y+33,40,'#fa3');Snd.fx.boom()}
  }
}

class Shot{
  constructor(x,y,d,vy=0){Object.assign(this,{x,y,w:14,h:6,vx:d*9,vy,dead:false})}
  update(G){
    this.x+=this.vx;this.y+=this.vy;
    if(G.level.solid(Math.floor((this.x+(this.vx>0?this.w:0))/TS),Math.floor(this.y/TS))||this.x<0||this.x>G.level.w*TS)this.dead=true;
    for(const e of G.enemies)if(!e.dead&&overlap(this,e)){e.hurt(G,Math.sign(this.vx),1);this.dead=true}
  }
  draw(c){c.save();c.translate(this.x,this.y);if(this.vx<0)c.scale(-1,1),c.translate(-14,0);R(c,'#ccd',0,1,10,4);R(c,'#889',10,2,4,2);R(c,'#a33',-2,0,3,6);c.restore()}
}
