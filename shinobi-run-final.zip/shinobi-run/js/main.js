'use strict';
const cv=document.getElementById('c'),c=cv.getContext('2d');
let G={state:'menu',shake:0,parts:[],shots:[],es:[],time:0,score:0,coins:0,txt:[],flash:0,tt:0,set:{diff:1,music:true,sfx:true,touch:'ontouchstart' in window}};
const SAVE='shinobiRunSave';
const load=()=>{try{return JSON.parse(localStorage.getItem(SAVE))}catch(e){return null}};
const save=o=>{try{localStorage.setItem(SAVE,JSON.stringify(o))}catch(e){}};
const SET='shinobiRunSet';try{Object.assign(G.set,JSON.parse(localStorage.getItem(SET)))}catch(e){}
const saveSet=()=>{try{localStorage.setItem(SET,JSON.stringify(G.set))}catch(e){}Object.assign(Snd.cfg,{music:G.set.music,sfx:G.set.sfx})};saveSet();
const HP=[5,3,2],MUL=[.7,1,1.3];
const mkP=(x,y)=>{const p=new Player(x,y);p.max=p.hp=HP[G.set.diff];return p};
addEventListener('keydown',e=>{Snd.init();if(e.code==='KeyN'&&G.state!=='menu')Snd.mute()});
const text=(t,x,y,s,col='#fff',al='center')=>{c.font=`bold ${s}px "Trebuchet MS",sans-serif`;c.textAlign=al;c.fillStyle='#000';c.fillText(t,x+2,y+2);c.fillStyle=col;c.fillText(t,x,y)};
G.puff=(x,y,n,col)=>{for(let i=0;i<n;i++)G.parts.push({x,y,vx:rnd(-2.5,2.5),vy:rnd(-3.5,.5),life:rnd(15,30),col})};

function story(n,k){G.story={n,k,i:0,c:0,lines:STORY[n][k]};G.state='story'}
function startLevel(n){
  const L=new Level(n);
  Object.assign(G,{lvl:n,level:L,txt:[],flash:0,shots:[],es:[],parts:[],cam:0,time:0,msg:0,shake:0,locked:false,bossDead:false,banner:150,bt:`World ${n+1}: ${L.th.name}`,
    spawn:{x:2*TS,y:15*TS-38},dj:n>=1,
    items:L.coins.map(([x,y])=>({x,y,w:16,h:16,got:false})),
    hearts:L.hearts.map(([x,y])=>({x,y,w:16,h:16,got:false})),
    pups:L.pups.map(([t,x,y])=>({t,x,y,w:20,h:20,got:false})),
    enemies:L.enemies.map(([t,x,y])=>new Enemy(t,x,y))});
  G.boss=new Boss(L.bossDef,(L.w-12)*TS,15*TS-66,MUL[G.set.diff]);
  G.p=mkP(G.spawn.x,G.spawn.y);Snd.music(n);
}
function newGame(n,keep){if(!keep){G.score=0;G.coins=0;G.tt=0}G.lives=HP[G.set.diff];story(n,'intro')}
G.die=()=>{
  G.lives--;G.shake=14;Snd.fx.hurt();
  if(G.lives<=0){G.state='over';Snd.music(-1);return}
  G.p=mkP(G.spawn.x,G.spawn.y);G.p.inv=90;G.msg=90;G.mt='Respawn';
};
const PW={r:['#4cf','Rasengan!'],c:['#fa3','Shadow Clones!'],h:['#4f6','Chakra Haste!']};

function update(){
  tick();G.time++;G.tt++;
  const L=G.level,p=G.p,B=G.boss;
  p.update(G);
  for(const e of G.enemies)e.update(G);
  if(!G.locked&&p.x>(L.arena+5)*TS){
    G.locked=true;B.active=true;G.spawn={x:(L.arena+6)*TS,y:15*TS-38};
    for(let y=0;y<15;y++)L.t[y][L.arena+3]='#';
    G.banner=150;G.bt='BOSS: '+B.name;G.shake=12;Snd.boss(true);Snd.fx.boom();
  }
  B.update(G);
  if(B.dead&&!G.bossDead){G.bossDead=true;Snd.boss(false);Snd.fx.win();G.banner=150;G.bt='Gate open! Run to the end!'}
  for(const s of G.shots)s.update(G);
  if(B.active&&!B.dead)for(const s of G.shots)if(!s.dead&&overlap(s,B)){B.hurt(G,Math.sign(s.vx),1);s.dead=true}
  G.shots=G.shots.filter(s=>!s.dead);
  for(const s of G.es){s.x+=s.vx;s.y+=s.vy;if(L.solid(Math.floor(s.x/TS),Math.floor(s.y/TS)))s.dead=true;if(overlap(s,p)){p.hurt(G,Math.sign(s.vx)||1);s.dead=true}}
  G.es=G.es.filter(s=>!s.dead&&s.x>0&&s.x<L.w*TS);
  for(const i of G.items)if(!i.got&&overlap(p,i)){i.got=true;G.coins++;G.score+=10;G.puff(i.x+8,i.y+8,4,'#fd0');Snd.fx.coin()}
  for(const h of G.hearts)if(!h.got&&overlap(p,h)&&p.hp<p.max){h.got=true;p.hp++;G.puff(h.x+8,h.y+8,8,'#f66');Snd.fx.power()}
  for(const u of G.pups)if(!u.got&&overlap(p,u)){u.got=true;p.pw[u.t]=600;G.msg=90;G.mt=PW[u.t][1];G.puff(u.x+10,u.y+10,14,PW[u.t][0]);Snd.fx.power();G.score+=50}
  for(const k of L.checks)if(!k.on&&p.x>k.x){k.on=true;G.spawn={x:k.x,y:15*TS-38};G.msg=90;G.mt='Checkpoint!';G.puff(k.x+8,k.y,10,'#4f4');Snd.fx.power()}
  const sx=Math.floor((p.x+p.w/2)/TS),sy=Math.floor((p.y+p.h-4)/TS);
  if(L.ch(sx,sy)==='^'&&p.y+p.h>(sy+1)*TS-14)p.hurt(G,-p.face);
  if(p.y>H+60){G.p.hp=0;G.die()}
  if(G.bossDead&&p.x>L.goalX){Snd.fx.win();story(G.lvl,'clear');return}
  for(const q of G.parts){q.x+=q.vx;q.y+=q.vy;q.vy+=.15;q.life--}G.parts=G.parts.filter(q=>q.life>0);
  const tgt=Math.max(0,Math.min(L.w*TS-W,p.x-W/2.4+p.face*40));G.cam+=(tgt-G.cam)*.12;
  G.txt.forEach(t=>{t.y-=.7;t.life--});G.txt=G.txt.filter(t=>t.life>0);if(G.flash>0)G.flash--;if(G.parts.length>300)G.parts.splice(0,G.parts.length-300);
  G.shake*=.85;G.msg--;G.banner--;
}

const SK={};
function skyCache(th,n){if(SK[n])return SK[n];const k=document.createElement('canvas');k.width=W;k.height=H;const x=k.getContext('2d');
  const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,th.sky[0]);g.addColorStop(1,th.sky[1]);x.fillStyle=g;x.fillRect(0,0,W,H);
  if(n>=2){x.fillStyle='#fff';for(let i=0;i<50;i++)x.fillRect((i*197)%W,(i*83)%260,2,2)}
  x.fillStyle=n===2?'#e8e8ff':n===1?'#ffd9a0':n>=3?'#ff9a8a':'#fff8c0';x.beginPath();x.arc(780,n===1?200:90,n===1?60:40,0,7);x.fill();return SK[n]=k}
function bg(cam,th,n){
  c.drawImage(skyCache(th,n),0,0);
  c.fillStyle=th.far;for(let i=-1;i<9;i++){const x=i*260-(cam*.15)%260;c.beginPath();c.moveTo(x,480);c.lineTo(x+130,250+(i%3)*30);c.lineTo(x+260,480);c.fill()}
  c.fillStyle=th.near;for(let i=-1;i<12;i++){const x=i*140-(cam*.4)%140;c.beginPath();c.arc(x+70,500,95,Math.PI,0);c.fill();if(n===0)R(c,'#6b4a2a',x+66,400,8,100);else if(n>=2)R(c,th.far,x+60,380,20,120)}
}
function drawLevel(){
  const L=G.level,th=L.th,x0=Math.floor(G.cam/TS),x1=x0+Math.ceil(W/TS)+1,t=G.time;
  for(let y=0;y<L.h;y++)for(let x=x0;x<=x1&&x<L.w;x++){
    const ch=L.t[y][x],px=x*TS,py=y*TS;
    if(ch==='#'){R(c,th.g,px,py,TS,TS);R(c,'rgba(0,0,0,.25)',px+4,py+8,6,4);R(c,'rgba(0,0,0,.25)',px+18,py+20,8,4);if(!L.solid(x,y-1)){R(c,th.gt,px,py,TS,7);R(c,'rgba(0,0,0,.2)',px,py+7,TS,2)}}
    else if(ch==='='){R(c,th.p,px,py,TS,TS);R(c,'rgba(0,0,0,.3)',px,py+TS-5,TS,5);R(c,'rgba(0,0,0,.15)',px,py+10,TS,2);R(c,'rgba(0,0,0,.15)',px,py+22,TS,2)}
    else if(ch==='^'){c.fillStyle='#bbc';for(let i=0;i<2;i++){c.beginPath();c.moveTo(px+i*16,py+TS);c.lineTo(px+i*16+8,py+TS-18);c.lineTo(px+i*16+16,py+TS);c.fill()}}
  }
  for(const k of L.checks){R(c,'#654',k.x,k.y,4,64);R(c,k.on?'#3c3':'#c33',k.x+4,k.y+2,24,16)}
  const gx=L.goalX,o=G.bossDead;R(c,'#a22',gx,15*TS-128,10,128);R(c,'#a22',gx+70,15*TS-128,10,128);R(c,'#822',gx-10,15*TS-140,100,14);R(c,'#a22',gx-4,15*TS-120,88,8);
  if(o){c.globalAlpha=.4+.2*Math.sin(t*.1);R(c,'#ffd',gx+10,15*TS-112,60,112);c.globalAlpha=1}
  text('LEAF',gx+40,15*TS-146,16,'#fff');
  for(const i of G.items)if(!i.got){const w=Math.abs(Math.sin(t*.08+i.x))*14+2;R(c,'#e8d08a',i.x+8-w/2,i.y,w,16);R(c,'#a33',i.x+8-w/2,i.y+6,w,3)}
  for(const h of G.hearts)if(!h.got)text('♥',h.x+8,h.y+16+Math.sin(t*.1)*2,22,'#f33');
  for(const u of G.pups)if(!u.got){const y=u.y+Math.sin(t*.1+u.x)*3;c.fillStyle=PW[u.t][0];c.beginPath();c.arc(u.x+10,y+10,11,0,7);c.fill();c.fillStyle='#fff';c.beginPath();c.arc(u.x+10,y+10,5,0,7);c.fill()}
}
function hud(){
  const p=G.p;R(c,'rgba(0,0,0,.45)',8,8,200,70);
  for(let i=0;i<p.max;i++)text('♥',16+i*30,40,30,i<p.hp?'#f33':'#555','left');
  text('Lives x'+G.lives,16,68,18,'#fff','left');
  text('Scrolls: '+G.coins,W-16,30,20,'#ffd','right');text('Score: '+G.score,W-16,56,20,'#fff','right');
  let i=0;for(const k in PW)if(p.pw[k]>0){R(c,PW[k][0],W-166,70+i*22,p.pw[k]/600*150,12);text(PW[k][1].replace('!',''),W-172,82+i*22,14,PW[k][0],'right');i++}
  const B=G.boss;
  if(B.active&&!B.dead){R(c,'rgba(0,0,0,.6)',W/2-200,H-40,400,22);R(c,'#c22',W/2-198,H-38,396*B.hp/B.max,18);text(B.name,W/2,H-23,15)}
  if(G.banner>0){c.globalAlpha=Math.min(1,G.banner/40);text(G.bt,W/2,150,38,'#ffd');c.globalAlpha=1}
  if(G.msg>0)text(G.mt,W/2,200,22);
}
function overlay(t,sub,col='#fff'){c.fillStyle='rgba(0,0,0,.6)';c.fillRect(0,0,W,H);text(t,W/2,200,64,col);sub.forEach((s,i)=>text(s,W/2,270+i*34,22,'#ddd'))}

function render(){
  if(G.state==='menu'||G.state==='story'||G.state==='win'||G.state==='settings'){
    const n=G.state==='story'?G.story.n:G.state==='win'?4:0;bg(G.time*2,THEMES[n],n);G.time++;
    c.fillStyle='rgba(0,0,0,.5)';c.fillRect(0,0,W,H);
    if(G.state==='menu'){
      const sv=load();
      text('SHINOBI RUN',W/2,160,84,'#ff8a00');text('A Leaf Village Adventure',W/2,205,26);
      text(sv?`ENTER: Continue (World ${sv.lvl+1})`:'ENTER: Start',W/2,285,30,'#ffd');text((sv?'N: New game     ':'')+'S: Settings',W/2,320,22,'#ddd');
      ['←/→ A/D move, Shift run   Space/W/↑ jump (double jump later)','J punch   K kunai   Stomp enemies   Orbs = power-ups','P/Esc pause   N mute'].forEach((s,i)=>text(s,W/2,380+i*30,19,'#ddd'));
    }else if(G.state==='settings'){drawSettings()}else if(G.state==='story'){
      const s=G.story,n=Math.floor(s.c*.8);R(c,'rgba(0,0,0,.6)',80,140,800,260);
      text(`WORLD ${s.n+1}: ${THEMES[s.n].name}`,W/2,190,32,'#ff8a00');
      for(let i=0;i<=s.i;i++)text(i<s.i?s.lines[i]:s.lines[i].slice(0,n),W/2,245+i*38,24,i<s.i?'#bbb':'#fff');
      text('ENTER ▶',W-110,380,18,'#ffd');
    }else{
      text('THE END',W/2,190,80,'#ffd');text('The scrolls are home. Konoha is safe!',W/2,240,26);text(`Score ${G.score}   Scrolls ${G.coins}   Time ${Math.floor(G.tt/3600)}:${String(Math.floor(G.tt/60)%60).padStart(2,'0')}   ${['Easy','Normal','Hard'][G.set.diff]}`,W/2,290,22,'#8f8');
      text('Thanks for playing, Hokage-to-be!',W/2,335,22,'#ddd');text('ENTER: main menu',W/2,370,22,'#ffd');
    }
    return;
  }
  c.save();bg(G.cam,G.level.th,G.lvl);
  c.translate(-Math.round(G.cam)+(Math.random()-.5)*G.shake,(Math.random()-.5)*G.shake);
  drawLevel();for(const e of G.enemies)if(e.x>G.cam-120&&e.x<G.cam+W+120)e.draw(c);if(G.boss.active)G.boss.draw(c);
  for(const s of G.shots)s.draw(c);for(const s of G.es)R(c,'#c9c',s.x,s.y,s.w,s.h);G.p.draw(c);
  for(const q of G.parts){c.globalAlpha=Math.min(1,q.life/15);R(c,q.col||'#fff',q.x,q.y,4,4)}c.globalAlpha=1;
  for(const t of G.txt)text(t.s,t.x,t.y,18,'#ffd');
  c.restore();hud();touchUI();if(G.flash>0){c.globalAlpha=G.flash/30;R(c,'#fff',0,0,W,H);c.globalAlpha=1}
  if(G.state==='pause')overlay('PAUSED',['Esc/P: resume','R: restart level','M: main menu','N: mute']);
  if(G.state==='over')overlay('GAME OVER',['R: retry this world','M: main menu'],'#f55');
}

function drawSettings(){const s=G.set;text('SETTINGS',W/2,150,56,'#ff8a00');
  [['D','Difficulty',['Easy','Normal','Hard'][s.diff]],['M','Music',s.music?'ON':'OFF'],['X','Sound FX',s.sfx?'ON':'OFF'],['T','Touch controls',s.touch?'ON':'OFF']].forEach(([k,n,v],i)=>text(`${k}: ${n}  <  ${v}  >`,W/2,240+i*50,28,'#ffd'));
  text('Esc / Enter: back',W/2,470,20,'#ddd')}
const TB=[['ArrowLeft','◀',16,444],['ArrowRight','▶',116,444],['Space','▲',W-116,444],['KeyJ','J',W-216,444],['KeyK','K',W-316,444]],BS=90;
function touchUI(){if(!G.set.touch||G.state!=='play')return;c.globalAlpha=.4;for(const[,l,x,y]of TB){c.fillStyle='#000';c.fillRect(x,y,BS,BS-10);text(l,x+BS/2,y+52,34)}text('II',W/2,36,26);c.globalAlpha=1}
function touch(e){e.preventDefault();G.set.touch=true;const r=cv.getBoundingClientRect(),on={};
  for(const t of e.touches){const x=(t.clientX-r.left)*W/r.width,y=(t.clientY-r.top)*H/r.height;
    if(G.state!=='play')on.Enter=1;else if(y<60&&Math.abs(x-W/2)<60)on.Escape=1;
    for(const[k,,bx,by]of TB)if(x>bx-12&&x<bx+BS+12&&y>by-12&&y<by+BS+12)on[k]=1}
  for(const k of[...TB.map(b=>b[0]),'Enter','Escape']){if(on[k]&&!keys[k])pressed[k]=1;keys[k]=!!on[k]}}
['touchstart','touchmove','touchend','touchcancel'].forEach(n=>cv.addEventListener(n,touch,{passive:false}));
let last=0,acc=0;
function loop(ts){
  acc+=Math.min(100,ts-last);last=ts;
  while(acc>=1000/60){
    acc-=1000/60;
    if(G.state==='menu'){
      const sv=load();
      if(hit('KeyN')){try{localStorage.removeItem(SAVE)}catch(e){}newGame(0)}
      else if(hit('KeyS'))G.state='settings';
      else if(hit('Enter','Space')){if(sv){G.score=sv.score;G.coins=sv.coins;G.tt=sv.tt||0;newGame(sv.lvl,true)}else newGame(0)}
    }
    else if(G.state==='settings'){const s=G.set;if(hit('KeyD'))s.diff=(s.diff+1)%3;if(hit('KeyM'))s.music=!s.music;if(hit('KeyX'))s.sfx=!s.sfx;if(hit('KeyT'))s.touch=!s.touch;if(hit('Escape','Enter'))G.state='menu';saveSet()}
    else if(G.state==='story'){
      const s=G.story,ln=s.lines[s.i];s.c++;
      if(hit('Enter','Space')){
        if(Math.floor(s.c*.8)<ln.length)s.c=ln.length/.8+1;
        else if(++s.i>=s.lines.length){
          if(s.k==='intro'){startLevel(s.n);G.state='play'}
          else if(s.n+1<5){save({lvl:s.n+1,score:G.score,coins:G.coins,tt:G.tt});story(s.n+1,'intro')}
          else{save({lvl:0,score:0,coins:0,tt:0});G.state='win'}
        }
      }
    }
    else if(G.state==='play'){if(hit('KeyP','Escape'))G.state='pause';else update()}
    else if(G.state==='pause'){if(hit('KeyP','Escape'))G.state='play';if(hit('KeyR')){G.lives=HP[G.set.diff];startLevel(G.lvl);G.state='play'}if(hit('KeyM'))G.state='menu'}
    else if(G.state==='over'){if(hit('KeyR','Enter')){G.lives=HP[G.set.diff];startLevel(G.lvl);G.state='play'}if(hit('KeyM'))G.state='menu'}
    else if(G.state==='win'){if(hit('Enter','KeyM'))G.state='menu'}
    endFrame();
  }
  render();requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
