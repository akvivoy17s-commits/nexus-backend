'use strict';
const TS=32,W=960,H=544;
const keys={};let pressed={};
addEventListener('keydown',e=>{if(!keys[e.code])pressed[e.code]=1;keys[e.code]=1;if(e.code.startsWith('Arrow')||e.code==='Space')e.preventDefault()});
addEventListener('keyup',e=>keys[e.code]=0);
addEventListener('blur',()=>{for(const k in keys)keys[k]=0});
const down=(...c)=>c.some(k=>keys[k]),hit=(...c)=>c.some(k=>pressed[k]);
const endFrame=()=>{pressed={}};
const overlap=(a,b)=>a.x<b.x+b.w&&a.x+a.w>b.x&&a.y<b.y+b.h&&a.y+a.h>b.y;
const rnd=(a,b)=>a+Math.random()*(b-a);

function moveBody(e,L){
  e.hitX=e.ground=false;
  e.x+=e.vx;let t=L.hit(e);
  if(t){e.x=e.vx>0?t.x*TS-e.w:(t.x+1)*TS;e.vx=0;e.hitX=true}
  e.y+=e.vy;t=L.hit(e);
  if(t){if(e.vy>0){e.y=t.y*TS-e.h;e.ground=true}else e.y=(t.y+1)*TS;e.vy=0}
}
