# Shinobi Run
Open `index.html` in a browser. No install needed.

Controls: ←/→ or A/D move, Shift run, Space/W/↑ jump (double jump from World 2), J punch, K kunai, P/Esc pause, N mute. Touch buttons appear on mobile.

Structure: `js/engine.js` (input, physics) · `js/entities.js` (player, enemies, boss) · `js/levels.js` (worlds, themes, story) · `js/audio.js` (synth SFX/music) · `js/main.js` (game loop, UI, save, settings).
